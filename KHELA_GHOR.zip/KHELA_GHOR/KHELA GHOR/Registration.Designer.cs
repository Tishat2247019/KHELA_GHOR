﻿namespace LOGIN_REGISTRATION
{
    partial class Registration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Registration));
            this.panel1 = new System.Windows.Forms.Panel();
            this.SignUp_lable1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button_signup = new System.Windows.Forms.Button();
            this.email_before = new System.Windows.Forms.PictureBox();
            this.email_after = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.TxtBox_Email = new System.Windows.Forms.TextBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtBoxConPassword_Signup = new System.Windows.Forms.TextBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtBoxPassword_Signup = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.SignUp_label2 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider3 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider4 = new System.Windows.Forms.ErrorProvider(this.components);
            this.btnBack_Signup = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.email_before)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.email_after)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.AutoSize = true;
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel1.Controls.Add(this.SignUp_label2);
            this.panel1.Controls.Add(this.SignUp_lable1);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.button_signup);
            this.panel1.Controls.Add(this.email_before);
            this.panel1.Controls.Add(this.email_after);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.TxtBox_Email);
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.txtBoxConPassword_Signup);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.txtBoxPassword_Signup);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pictureBox7);
            this.panel1.Controls.Add(this.pictureBox6);
            this.panel1.Controls.Add(this.pictureBox9);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox8);
            this.panel1.Location = new System.Drawing.Point(637, 96);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(381, 470);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // SignUp_lable1
            // 
            this.SignUp_lable1.AutoSize = true;
            this.SignUp_lable1.Font = new System.Drawing.Font("Roboto Mono", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SignUp_lable1.Location = new System.Drawing.Point(3, 13);
            this.SignUp_lable1.Name = "SignUp_lable1";
            this.SignUp_lable1.Size = new System.Drawing.Size(375, 25);
            this.SignUp_lable1.TabIndex = 21;
            this.SignUp_lable1.Text = "Let\'s Create a Khela Ghor Account";
            this.SignUp_lable1.Click += new System.EventHandler(this.Label_SignUp_Click);
            // 
            // button1
            // 
            this.button1.AutoSize = true;
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 2;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(40, 399);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(307, 59);
            this.button1.TabIndex = 20;
            this.button1.Text = "LOGIN";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button_signup
            // 
            this.button_signup.AutoSize = true;
            this.button_signup.BackColor = System.Drawing.Color.Coral;
            this.button_signup.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_signup.FlatAppearance.BorderSize = 2;
            this.button_signup.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_signup.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_signup.Location = new System.Drawing.Point(37, 296);
            this.button_signup.Name = "button_signup";
            this.button_signup.Size = new System.Drawing.Size(307, 59);
            this.button_signup.TabIndex = 19;
            this.button_signup.Text = "SIGN UP";
            this.button_signup.UseVisualStyleBackColor = false;
            this.button_signup.Click += new System.EventHandler(this.button_signup_Click);
            // 
            // email_before
            // 
            this.email_before.Image = global::KHELA_GHOR.Properties.Resources.Asset_9;
            this.email_before.Location = new System.Drawing.Point(37, 107);
            this.email_before.Name = "email_before";
            this.email_before.Size = new System.Drawing.Size(26, 33);
            this.email_before.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.email_before.TabIndex = 18;
            this.email_before.TabStop = false;
            this.email_before.Click += new System.EventHandler(this.email_before_Click);
            // 
            // email_after
            // 
            this.email_after.Image = global::KHELA_GHOR.Properties.Resources.EMAIL_AFTER_1;
            this.email_after.Location = new System.Drawing.Point(37, 112);
            this.email_after.Name = "email_after";
            this.email_after.Size = new System.Drawing.Size(23, 29);
            this.email_after.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.email_after.TabIndex = 17;
            this.email_after.TabStop = false;
            this.email_after.Click += new System.EventHandler(this.email_after_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(119)))), ((int)(((byte)(55)))));
            this.panel5.Location = new System.Drawing.Point(37, 147);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(307, 4);
            this.panel5.TabIndex = 16;
            this.panel5.Paint += new System.Windows.Forms.PaintEventHandler(this.panel5_Paint);
            // 
            // TxtBox_Email
            // 
            this.TxtBox_Email.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtBox_Email.Font = new System.Drawing.Font("Roboto Mono", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtBox_Email.Location = new System.Drawing.Point(69, 115);
            this.TxtBox_Email.Name = "TxtBox_Email";
            this.TxtBox_Email.Size = new System.Drawing.Size(267, 26);
            this.TxtBox_Email.TabIndex = 15;
            this.TxtBox_Email.TabStop = false;
            this.TxtBox_Email.Text = "Email";
            this.TxtBox_Email.MouseClick += new System.Windows.Forms.MouseEventHandler(this.TxtBox_Email_MouseClick_1);
            this.TxtBox_Email.TextChanged += new System.EventHandler(this.TxtBox_Email_TextChanged);
            this.TxtBox_Email.Leave += new System.EventHandler(this.TxtBox_Email_Leave);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::KHELA_GHOR.Properties.Resources.Asset_1;
            this.pictureBox5.Location = new System.Drawing.Point(313, 233);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(23, 28);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 11;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            this.pictureBox5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox5_MouseDown);
            this.pictureBox5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox5_MouseUp);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(119)))), ((int)(((byte)(55)))));
            this.panel4.Location = new System.Drawing.Point(37, 267);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(307, 4);
            this.panel4.TabIndex = 10;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // txtBoxConPassword_Signup
            // 
            this.txtBoxConPassword_Signup.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBoxConPassword_Signup.Font = new System.Drawing.Font("Roboto Mono", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxConPassword_Signup.Location = new System.Drawing.Point(69, 236);
            this.txtBoxConPassword_Signup.Name = "txtBoxConPassword_Signup";
            this.txtBoxConPassword_Signup.Size = new System.Drawing.Size(225, 26);
            this.txtBoxConPassword_Signup.TabIndex = 90;
            this.txtBoxConPassword_Signup.TabStop = false;
            this.txtBoxConPassword_Signup.Text = "Confirm Password";
            this.txtBoxConPassword_Signup.MouseClick += new System.Windows.Forms.MouseEventHandler(this.textBox3_MouseClick);
            this.txtBoxConPassword_Signup.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            this.txtBoxConPassword_Signup.Leave += new System.EventHandler(this.txtBoxConPassword_Signup_Leave);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::KHELA_GHOR.Properties.Resources.Asset_1;
            this.pictureBox4.Location = new System.Drawing.Point(313, 177);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(23, 28);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 7;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            this.pictureBox4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox4_MouseDown);
            this.pictureBox4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox4_MouseUp);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(119)))), ((int)(((byte)(55)))));
            this.panel3.Location = new System.Drawing.Point(37, 211);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(307, 4);
            this.panel3.TabIndex = 5;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(119)))), ((int)(((byte)(55)))));
            this.panel2.Location = new System.Drawing.Point(38, 93);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(307, 4);
            this.panel2.TabIndex = 3;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // txtBoxPassword_Signup
            // 
            this.txtBoxPassword_Signup.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBoxPassword_Signup.Font = new System.Drawing.Font("Roboto Mono", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxPassword_Signup.Location = new System.Drawing.Point(69, 179);
            this.txtBoxPassword_Signup.Name = "txtBoxPassword_Signup";
            this.txtBoxPassword_Signup.Size = new System.Drawing.Size(225, 26);
            this.txtBoxPassword_Signup.TabIndex = 40;
            this.txtBoxPassword_Signup.TabStop = false;
            this.txtBoxPassword_Signup.Text = "Password";
            this.txtBoxPassword_Signup.MouseClick += new System.Windows.Forms.MouseEventHandler(this.textBox2_MouseClick);
            this.txtBoxPassword_Signup.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            this.txtBoxPassword_Signup.Leave += new System.EventHandler(this.txtBoxPassword_Signup_Leave);
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Roboto Mono", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(69, 63);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(267, 26);
            this.textBox1.TabIndex = 20;
            this.textBox1.TabStop = false;
            this.textBox1.Text = "Username";
            this.textBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.textBox1_MouseClick);
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            this.textBox1.Leave += new System.EventHandler(this.textBox1_Leave);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::KHELA_GHOR.Properties.Resources.USER_FIRST;
            this.pictureBox2.Location = new System.Drawing.Point(37, 63);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(26, 25);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::KHELA_GHOR.Properties.Resources.USER_AFTER;
            this.pictureBox7.Location = new System.Drawing.Point(37, 63);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(22, 22);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 12;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Visible = false;
            this.pictureBox7.Click += new System.EventHandler(this.pictureBox7_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::KHELA_GHOR.Properties.Resources.PASSWORD_FIRSTT;
            this.pictureBox6.Location = new System.Drawing.Point(40, 236);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(26, 25);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 8;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox6_Click);
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::KHELA_GHOR.Properties.Resources.PASSWORD_AFTER;
            this.pictureBox9.Location = new System.Drawing.Point(40, 236);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(23, 26);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 14;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Click += new System.EventHandler(this.pictureBox9_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::KHELA_GHOR.Properties.Resources.PASSWORD_FIRSTT;
            this.pictureBox3.Location = new System.Drawing.Point(37, 178);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(26, 25);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::KHELA_GHOR.Properties.Resources.PASSWORD_AFTER;
            this.pictureBox8.Location = new System.Drawing.Point(38, 177);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(23, 26);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 13;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Visible = false;
            this.pictureBox8.Click += new System.EventHandler(this.pictureBox8_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::KHELA_GHOR.Properties.Resources.REGISTER_SCREEN_KHELAGHOR_LOGORIGHT;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1095, 632);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // SignUp_label2
            // 
            this.SignUp_label2.AutoSize = true;
            this.SignUp_label2.Font = new System.Drawing.Font("Roboto Mono", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SignUp_label2.Location = new System.Drawing.Point(65, 376);
            this.SignUp_label2.Name = "SignUp_label2";
            this.SignUp_label2.Size = new System.Drawing.Size(243, 20);
            this.SignUp_label2.TabIndex = 91;
            this.SignUp_label2.Text = "Already A khela Ghor User?\r\n";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            this.errorProvider3.ContainerControl = this;
            // 
            // errorProvider4
            // 
            this.errorProvider4.ContainerControl = this;
            // 
            // btnBack_Signup
            // 
            this.btnBack_Signup.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBack_Signup.BackgroundImage")));
            this.btnBack_Signup.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnBack_Signup.FlatAppearance.BorderSize = 0;
            this.btnBack_Signup.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack_Signup.Location = new System.Drawing.Point(4, 5);
            this.btnBack_Signup.Name = "btnBack_Signup";
            this.btnBack_Signup.Size = new System.Drawing.Size(34, 34);
            this.btnBack_Signup.TabIndex = 5;
            this.btnBack_Signup.UseVisualStyleBackColor = true;
            this.btnBack_Signup.Click += new System.EventHandler(this.btnBack_Signup_Click);
            // 
            // Registration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1095, 632);
            this.Controls.Add(this.btnBack_Signup);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Registration";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registration";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.email_before)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.email_after)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtBoxPassword_Signup;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txtBoxConPassword_Signup;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox TxtBox_Email;
        private System.Windows.Forms.PictureBox email_after;
        private System.Windows.Forms.PictureBox email_before;
        private System.Windows.Forms.Button button_signup;
        private System.Windows.Forms.Label SignUp_lable1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label SignUp_label2;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.ErrorProvider errorProvider3;
        private System.Windows.Forms.ErrorProvider errorProvider4;
        private System.Windows.Forms.Button btnBack_Signup;
    }
}